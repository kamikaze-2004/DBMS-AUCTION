// src/components/Loading.js
import React from "react";
import "../styles/loading.css"

export default function Loading() {
  return <div id="loading"></div>;
}
